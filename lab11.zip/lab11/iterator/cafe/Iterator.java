package hus.oop.lab11.iterator.cafe;

public interface Iterator {
    boolean hasNext();
    Object next();
}
