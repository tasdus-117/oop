package hus.oop.lab7.InterfacesResizableGeometricObject;

public interface Resizable {
    public void resize(int percent);
}
