package hus.oop.lab11.factory.button;

public interface Button {
    void render();
    void onClick();
}
