package hus.oop.lab11.factory.fruits;

public class Orange implements Fruits {
    @Override
    public void produceJuice() {
        System.out.println("Orange juice");
    }
}
