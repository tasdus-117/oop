package hus.oop.lab7.AbstractAnimal;

public class BigDog extends Dog {
    public BigDog(String name) {
        super(name);
    }
    public void greets() {
        System.out.println("Wooow");
    }
    public void greets(Dog another) {
        System.out.println("Woooooow");
    }
    public void greets(BigDog another) {
        System.out.println("Wooooooooooow");
    }
}
