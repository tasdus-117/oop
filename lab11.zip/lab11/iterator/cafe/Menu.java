package hus.oop.lab11.iterator.cafe;

public interface Menu {
    public Iterator createIterator();
}
