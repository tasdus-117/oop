package hus.oop.lab11.abstractfactory.shape;

public abstract class AbtractFactory {
    abstract Shape getShape(String shapeType);
}
