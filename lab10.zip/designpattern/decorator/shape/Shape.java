package hus.oop.designpattern.decorator.shape;

public abstract class Shape {
    abstract void draw();
}
