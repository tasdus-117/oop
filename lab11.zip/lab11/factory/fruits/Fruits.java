package hus.oop.lab11.factory.fruits;

public interface Fruits {
    void produceJuice();
}
