package hus.oop.lab11.iterator.employee;

public interface EmployeeIterable {
    public Iterator getIterator();
}
