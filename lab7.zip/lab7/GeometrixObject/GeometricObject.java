package hus.oop.lab7.GeometrixObject;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();
}
