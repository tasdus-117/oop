package hus.oop.designpattern.decorator.icecream;

public interface IceCream {
    public String getDescription();
}
