package hus.oop.designpattern.decorator.icecream;

public class ChocolateIceCream implements IceCream {
    public String getDescription() {
        return "Chocolate Ice Cream";
    }
}
