package hus.oop.lab7.InterfacesResizableGeometricObject;

public interface GeometricObject {
    public double getPerimeter();
    public double getArea();
}
