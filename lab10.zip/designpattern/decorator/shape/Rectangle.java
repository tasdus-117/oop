package hus.oop.designpattern.decorator.shape;

public class Rectangle extends Shape {
    void draw() {
        System.out.println("Rectangle!!");
    }
}
