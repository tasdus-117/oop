package hus.oop.lab11.factory.fruits;

public class Apple implements Fruits {
    @Override
    public void produceJuice() {
        System.out.println("Apple juice");
    }
}
