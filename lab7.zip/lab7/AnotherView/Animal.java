package hus.oop.lab7.AnotherView;

public abstract class Animal {
    abstract public void greeting();
}
