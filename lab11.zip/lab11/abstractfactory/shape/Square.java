package hus.oop.lab11.abstractfactory.shape;

public class Square implements Shape{
    @Override
    public void draw() {
        System.out.println("Draw square");
    }
}
