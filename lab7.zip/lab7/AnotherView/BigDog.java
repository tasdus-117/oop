package hus.oop.lab7.AnotherView;

public class BigDog extends Dog {
    @Override
    public void greeting() {
        System.out.println("Woow!");
    }
    public void greeting(Dog another) {
        System.out.println("Woooooooooooowwwwwwww!");
    }
}
