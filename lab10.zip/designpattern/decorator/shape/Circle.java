package hus.oop.designpattern.decorator.shape;

public class Circle extends Shape {
    void draw() {
        System.out.println("Circle");
    }
}
