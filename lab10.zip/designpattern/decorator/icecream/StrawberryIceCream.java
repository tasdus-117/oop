package hus.oop.designpattern.decorator.icecream;

public class StrawberryIceCream implements IceCream {
    public String getDescription() {
        return "Strawberry Ice Cream";
    }
}
