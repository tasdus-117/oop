package hus.oop.lab11.abstractfactory.shape;

public interface Shape {
    void draw();
}
