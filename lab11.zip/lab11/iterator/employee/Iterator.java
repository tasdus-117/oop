package hus.oop.lab11.iterator.employee;

public interface Iterator {
    public boolean hasNext();
    public Object next();
}
