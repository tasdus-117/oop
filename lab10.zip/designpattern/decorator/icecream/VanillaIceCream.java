package hus.oop.designpattern.decorator.icecream;

public class VanillaIceCream implements IceCream {
    public String getDescription() {
        return "Vanilla IceCream";
    }
}
