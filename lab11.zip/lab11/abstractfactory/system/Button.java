package hus.oop.lab11.abstractfactory.system;

public interface Button {
    void paint();
}
