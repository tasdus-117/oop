package hus.oop.lab11.visitor.exp;

public interface Book {
    void accept(Visitor v);
}
