package hus.oop.lab7.AnotherView;

public class Cat extends Animal{
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
